# MQTT to PostgreSQL Middleware

This Node.js script listens to MQTT messages on a specified topic, parses the JSON payload, and stores the data into a PostgreSQL database.

## Features
- Subscribes to MQTT topic
- Parses incoming JSON payloads
- Inserts sensor data into PostgreSQL
- Uses environment variables via `.env`

## Tech Stack
- Node.js
- `mqtt` for broker communication
- `pg` for PostgreSQL integration
- `dotenv` for environment variable management

## Requirements

```bash
npm install mqtt pg dotenv
```

## Environment Variables (.env)

Create a `.env` file in the root directory:

```env
DB_HOST=localhost
DB_PORT=
DB_USER=your_db_user
DB_PASSWORD=your_db_password
DB_NAME=your_db_name
MQTT_TOPIC=
```

## Usage

```bash
node mqtt_postgres.js
```

## PostgreSQL Table Schema

```sql
CREATE TABLE gnss (
    gnss_id TEXT,
    timestamp TIMESTAMP,
    sensor_id TEXT,
    value DOUBLE PRECISION
);
```

## Notes
- Make sure your MQTT broker is running and accessible
- The MQTT topic and message format should match the expected JSON structure
