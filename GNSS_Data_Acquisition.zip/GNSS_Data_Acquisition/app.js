const mqtt = require('mqtt');
const { Client } = require('pg');
const dotenv = require('dotenv');

dotenv.config();

const pgClient = new Client({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});

pgClient.connect()
  .then(() => console.log('Connected to PostgreSQL'))
  .catch(err => console.error('PostgreSQL connection error', err.stack));

const mqttClient = mqtt.connect(`mqtt://${process.env.DB_HOST}`);

mqttClient.on('connect', () => {
  console.log('Connected to MQTT broker');
  mqttClient.subscribe(process.env.MQTT_TOPIC, (err) => {
    if (err) {
      console.error('Failed to subscribe:', err);
    } else {
      console.log('Subscribed to topic');
    }
  });
});

mqttClient.on('message', (topic, message) => {
  console.log('Received message:', message.toString());

  try {
    const data = JSON.parse(message.toString());
    const gnss_id = 'GNSS5';
    const timestamp = new Date().toISOString(); 

    for (const [key, value] of Object.entries(data)) {
        if (key === 'timeNow5') {
            continue;
        }
        const sensor_id = key;
        const sensor_value = value;

        const query = 'INSERT INTO gnss (gnss_id, timestamp, sensor_id, value) VALUES ($1, $2, $3, $4)';
        const values = [gnss_id, timestamp, sensor_id, sensor_value];

        pgClient.query(query, values)
            .then(() => {
            console.log(`Inserted: ${sensor_id} = ${sensor_value}`);
            })
            .catch(err => {
            console.error('Error inserting data:', err);
            });
    }

  } catch (err) {
    console.error('Error parsing JSON message:', err);
  }
});
