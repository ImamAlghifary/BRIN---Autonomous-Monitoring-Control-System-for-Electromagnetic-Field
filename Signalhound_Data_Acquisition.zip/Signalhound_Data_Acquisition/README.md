# EMFM SignalHound Monitoring GUI

This is a desktop application for monitoring electromagnetic field data using the SignalHound device. 
The app performs automated frequency sweeps every 5 minutes, visualizes them in real-time using a Tkinter GUI, 
and stores the results in a PostgreSQL database. Every third sweep, it compresses the sweep CSV files and inserts them into the database.

##  Features
- Automated frequency sweep every 5 minutes (configurable for testing)
- Real-time plotting with `matplotlib`
- Logging and sweep status updates in GUI
- Periodic CSV zipping and database insertion
- Built-in PostgreSQL data uploader for SignalHound results

##  GUI Tools
- Tkinter for desktop GUI
- Matplotlib for plotting frequency data
- Seaborn for plot styling

##  Requirements
- SignalHound device with `sadevice` API
- PostgreSQL server (configured via `.env`)
- Python 3.7+

##  Setup

1. **Install Python dependencies**
```bash
pip install -r requirements.txt
```

2. **Set up `.env` file**
Create a `.env` file in the root directory with the following variables:

```env
DB_NAME=your_db_name
DB_USER=your_db_user
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=5432
```

3. **Run the application**
```bash
python emfm_gui.py
```

## Output
- Sweep CSV files are stored in the `sweeps/` folder
- Zipped every third sweep and inserted into PostgreSQL

## PostgreSQL Table Schema
You should have a table named `signalhound` with this schema:

```sql
CREATE TABLE signalhound (
    timestamp TIMESTAMP,
    frequency_hz DOUBLE PRECISION,
    power_dbm DOUBLE PRECISION
);
```

## Notes
- Make sure your SignalHound device is properly connected before starting the application.
- Adjust sweep parameters in the script as needed.
