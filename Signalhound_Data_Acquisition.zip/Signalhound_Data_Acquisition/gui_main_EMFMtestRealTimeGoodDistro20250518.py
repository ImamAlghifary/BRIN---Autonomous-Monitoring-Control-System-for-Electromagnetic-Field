import tkinter as tk
from tkinter import ttk, messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from dotenv import load_dotenv
import os
import csv
import time
import zipfile
import threading
from datetime import datetime
from matplotlib import pyplot as plt
import seaborn as sns; sns.set()

import psycopg2
from sadevice.sa_api import *

load_dotenv()

POSTGRES_CONFIG = {
    'dbname': os.getenv('DB_NAME'),
    'user': os.getenv('DB_USER'),
    'password': os.getenv('DB_PASSWORD'),
    'host': os.getenv('DB_HOST'),
    'port': os.getenv('DB_PORT')
}

class EMFMApp:
    def __init__(self, root):
        self.root = root
        self.root.title("AMCS EMFM - SignalHound Sweep")

        self.sweep_counter = 0
        self.sweep_data = []
        self.csv_folder = "sweeps"
        os.makedirs(self.csv_folder, exist_ok=True)

        self.figure, self.ax = plt.subplots(figsize=(8, 3))
        self.canvas = FigureCanvasTkAgg(self.figure, master=root)
        self.canvas.get_tk_widget().pack(padx=10, pady=10)

        self.status_box = tk.Text(root, height=5, width=100)
        self.status_box.pack()

        result = sa_open_device()
        if result["status"] != 0:
            raise RuntimeError("Failed to open Signal Hound device.")
        self.handle = result["handle"]

        self.append_status("Starting EMFM monitoring (auto sweep every 5 mins)...")
        self.schedule_next_sweep()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def append_status(self, text):
        timestamp = datetime.now().strftime('%H:%M:%S')
        self.status_box.insert(tk.END, f"[{timestamp}] {text}\n")
        self.status_box.see(tk.END)

    def schedule_next_sweep(self):
        self.root.after(10 * 1000, self.run_sweep)  # 10 seconds for testing

    def run_sweep(self):
        self.append_status("Performing frequency sweep...")

        sa_config_center_span(self.handle, 100e6, 2e6)
        sa_config_level(self.handle, -70.0)
        sa_config_sweep_coupling(self.handle, 10e3, 10e3, 0)
        sa_config_acquisition(self.handle, SA_MIN_MAX, SA_LOG_SCALE)
        sa_initiate(self.handle, SA_SWEEPING, 0)

        sweep = sa_get_sweep_32f(self.handle)
        powers = sweep["max"]
        sweep_info = sa_query_sweep_info(self.handle)
        start_freq = sweep_info["start_freq"]
        bin_size = sweep_info["bin_size"]
        freqs = [start_freq + i * bin_size for i in range(len(powers))]

        self.plot_data(freqs, powers)

        timestamp_now = datetime.now()
        csv_path = os.path.join(self.csv_folder, f"sweep_{timestamp_now.strftime('%Y%m%d_%H%M%S')}.csv")
        with open(csv_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["Timestamp", "Frequency (Hz)", "Power (dBm)"])
            for f_freq, p_power in zip(freqs, powers):
                writer.writerow([timestamp_now.isoformat(), f_freq, p_power])

        self.sweep_counter += 1
        self.append_status(f"Sweep saved to {csv_path} (Sweep #{self.sweep_counter})")

        if self.sweep_counter % 3 == 0:
            self.append_status("Zipping sweep files and inserting into PostgreSQL...")
            self.zip_and_insert()

        self.schedule_next_sweep()

    def plot_data(self, freqs, powers):
        self.ax.clear()
        self.ax.set_title("Sweep Result")
        self.ax.set_xlabel("Frequency (MHz)")
        self.ax.set_ylabel("Power (dBm)")
        self.ax.grid(True)
        self.ax.plot([f / 1e6 for f in freqs], powers)
        self.canvas.draw()

    def zip_and_insert(self):
        zip_name = datetime.now().strftime("EMFM_sweeps_%Y%m%d_%H%M%S.zip")
        zip_path = os.path.join(self.csv_folder, zip_name)

        with zipfile.ZipFile(zip_path, 'w') as zipf:
            for file in os.listdir(self.csv_folder):
                if file.endswith(".csv"):
                    file_path = os.path.join(self.csv_folder, file)
                    zipf.write(file_path, arcname=file)
                    self.insert_csv_to_postgres(file_path)
                    os.remove(file_path)

        self.append_status(f"Zipped files: {zip_path}")

    def insert_csv_to_postgres(self, csv_file):
        try:
            conn = psycopg2.connect(**POSTGRES_CONFIG)
            cur = conn.cursor()

            with open(csv_file, 'r') as f:
                next(f)
                cur.copy_expert(
                    sql="COPY signalhound(timestamp, frequency_hz, power_dbm) FROM STDIN WITH CSV",
                    file=f
                )

            conn.commit()
            cur.close()
            conn.close()
            self.append_status(f"Inserted data from {csv_file} into PostgreSQL.")
        except Exception as e:
            self.append_status(f"❌ Error inserting {csv_file} into PostgreSQL: {e}")

    def on_close(self):
        self.append_status("Shutting down gracefully...")
        sa_close_device(self.handle)
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = EMFMApp(root)
    root.mainloop()
